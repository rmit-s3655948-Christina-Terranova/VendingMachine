/******************************************************************************
** Student name: 	Christina Terranova
** Student number: 	s3655948
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#ifndef VM_H
#define VM_H

#include "vm_menu.h"

#define MENU_OPTION_1 "1"
#define MENU_OPTION_2 "2"
#define MENU_OPTION_3 "3"
#define MENU_OPTION_4 "4"
#define MENU_OPTION_5 "5"
#define MENU_OPTION_7 "7"
#define MENU_OPTION_9 "9"

#define BUFFSIZE 1000

void menu(VmSystem* system);

#endif
