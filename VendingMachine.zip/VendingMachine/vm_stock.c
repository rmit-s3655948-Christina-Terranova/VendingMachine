/******************************************************************************
** Student name: 	Christina Terranova
** Student number: 	s3655948
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#include "vm_stock.h"

/**
 * vm_stock.c this is the file where you will implement the
 * interface functions for managing the stock list.
 **/

/**
 * Some example functions:
 * create list, free list, create node, free node, insert node, etc...
 */

/** creates an empty list*/
int createList(VmSystem *system) {

    if ((system->itemList = malloc(sizeof(List))) == NULL) {
        return EXIT_FAILURE;
    }

    system->itemList->head = NULL;
    system->itemList->size = 0;

    return EXIT_SUCCESS;
}

/** free the list itself*/
void freeList(VmSystem *system) {
    free(system->itemList);
}

/** free nodes in the list and their stock data*/
void freeNode(VmSystem *system) {

    Node *current;
    Stock *data;

    while (system->itemList->head != NULL) {
        current = system->itemList->head;

        /* free stock data*/
        data = current->data;
        free(data);

        /* free node */
        system->itemList->head = system->itemList->head->next;
        free(current);
    }
    system->itemList->size = 0;

}

/** add a node to the list*/
int addNode(VmSystem *system, Stock *item) {

    Node *current, *previous, *newNode;

    if ((newNode = malloc(sizeof(Node))) == NULL) {
        fprintf(stderr, "Unable to add new node\n");
        return EXIT_FAILURE;
    }

    newNode->data = item;
    newNode->next = NULL;

    current = system->itemList->head;

    /** empty list - insert at node at head*/
    if (current == NULL)
        system->itemList->head = newNode;
    else {

        /** item comes before - insert node at start of list*/
        if (strcmp(item->name, current->data->name) < 0) {
            newNode->next = system->itemList->head;
            system->itemList->head = newNode;
        } else {
            /** find where to insert node somewhere in middle of list between previous and current*/
            previous = current;
            while (current != NULL) {
                if (strcmp(item->name, current->data->name) > 0) {
                    previous = current;
                    current = current->next;
                } else
                    break;
            }
            /** insert node in middle of list*/
            previous->next = newNode;
            newNode->next = current;
        }
    }
    system->itemList->size++;

    return EXIT_SUCCESS;
}



