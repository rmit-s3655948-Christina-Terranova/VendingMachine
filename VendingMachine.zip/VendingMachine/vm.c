/******************************************************************************
** Student name: 	Christina Terranova
** Student number: 	s3655948
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#include "vm.h"


int main(int argc, char **argv) {

    VmSystem system;

    if (argc != 2) {
        fprintf(stderr, "Incorrect number of arguments\n");
    } else {
        system.stockFileName = argv[1];
    }

    systemInit(&system);
    menu(&system);

    printf("Goodbye. \n\n");

    return EXIT_SUCCESS;
}

void menu(VmSystem *system) {

    char menuNo[BUFFSIZE];

    printf("\n\nMain Menu:\n1.Display Items\n2.Purchase Items\n3.Save and Exit\nAdministrator-Only Menu:\n"
                   "4.Add Item\n5.Remove Item\n6.Display Coins\n7.Reset Stock\n8.Reset Coins\n9.Abort Program\n"
                   "Select your option (1-9): ");
    fgets(menuNo, sizeof(menuNo), stdin);

    if (menuNo[strlen(menuNo) - 1] != '\n') {
        readRestOfLine();
    }
    menuNo[strlen(menuNo) - 1] = '\0';

    if (strcmp(menuNo, MENU_OPTION_1) == 0) {
        displayItems(system);
        menu(system);
    } else if (strcmp(menuNo, MENU_OPTION_2) == 0) {
        purchaseItem(system);
        menu(system);
    } else if (strcmp(menuNo, MENU_OPTION_3) == 0) {
        saveAndExit(system);
    } else if (strcmp(menuNo, MENU_OPTION_4) == 0) {
        addItem(system);
        menu(system);
    } else if (strcmp(menuNo, MENU_OPTION_5) == 0) {
        removeItem(system);
        menu(system);
    } else if (strcmp(menuNo, MENU_OPTION_7) == 0) {
        resetStock(system);
        menu(system);
    } else if (strcmp(menuNo, MENU_OPTION_9) == 0) {
        abortProgram(system);
    } else {
        menu(system);
    }
}


