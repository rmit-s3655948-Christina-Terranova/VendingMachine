/******************************************************************************
** Student name: 	Christina Terranova
** Student number: 	s3655948
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#include "vm_menu.h"

/**
 * vm_menu.c handles the initialisation and management of the menu array.
 **/

/**
 * In this function you need to initialise the array of menu items
 * according to the text to be displayed for the menu. This array is
 * an array of MenuItem with text and a pointer to the function
 * that will be called.
 **/
void initMenu(MenuItem * menu)
{
    strcpy(menu[0].text, "1.Display Items\n");
    menu[0].function = displayItems;

    strcpy(menu[1].text, "2.Purchase Items\n");
    menu[1].function = purchaseItem;

    strcpy(menu[2].text, "3.Save And Exit\n");
    menu[2].function = saveAndExit;

    strcpy(menu[3].text, "4.Add Item\n");
    menu[3].function = addItem;

    strcpy(menu[4].text, "5.Remove Item\n");
    menu[4].function = removeItem;

    strcpy(menu[5].text, "6.Display Coins\n");
    menu[5].function = displayCoins;

    strcpy(menu[6].text, "7.Reset Stock\n");
    menu[6].function = resetStock;

    strcpy(menu[7].text, "8.Reset Coins\n");
    menu[7].function = resetCoins;

    strcpy(menu[8].text, "9.Abort Program\n");
    menu[8].function = abortProgram;
}

/**
 * Gets input from the user and returns a pointer to the MenuFunction
 * that defines how to perform the user's selection. NULL is returned
 * if an invalid option is entered.
 **/
MenuFunction getMenuChoice(MenuItem * menu)
{
    char menuNo[BUFFSIZE];
    int i;
    char menuList[1000] = " ";

    for(i = 0; i < sizeof(menu) + 1; i++){
        strcpy(menuList, strcat(menuList, menu[i].text));
    }

    printf("%s", menuList);
    printf("Select your option (1-9): ");

    fgets(menuNo, sizeof(menuNo), stdin);
    if (menuNo[strlen(menuNo) - 1] != '\n') {
        readRestOfLine();
    }
    menuNo[strlen(menuNo) - 1] = '\0';

    if (strcmp(menuNo, MENU_OPTION_1) == 0) {
        return menu[0].function;
    }
    else if (strcmp(menuNo, MENU_OPTION_2) == 0) {
        return menu[1].function;
    }
    else if (strcmp(menuNo, MENU_OPTION_3) == 0) {
        return menu[2].function;
    }
    else if (strcmp(menuNo, MENU_OPTION_4) == 0) {
        return menu[3].function;
    }
    else if (strcmp(menuNo, MENU_OPTION_5) == 0) {
        return menu[4].function;
    }
    else if (strcmp(menuNo, MENU_OPTION_6) == 0) {
        return menu[5].function;
    }
    else if (strcmp(menuNo, MENU_OPTION_7) == 0) {
        return menu[6].function;
    }
    else if (strcmp(menuNo, MENU_OPTION_8) == 0) {
        return menu[7].function;
    }
    else if (strcmp(menuNo, MENU_OPTION_9) == 0) {
        return menu[8].function;
    }
    else{
        getMenuChoice(menu);
    }

    return NULL;
}
