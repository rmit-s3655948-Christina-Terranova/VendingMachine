/******************************************************************************
** Student name: 	Christina Terranova
** Student number: 	s3655948
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#include "vm_options.h"

/**
 * vm_options.c this is where you need to implement the system handling
 * functions (e.g., init, free, load, save) and the main options for
 * your program. You may however have some of the actual work done
 * in functions defined elsewhere.
 **/

/**
 * Initialise the system to a known safe state. Look at the structure
 * defined in vm_system.h.
 **/
Boolean systemInit(VmSystem *system) {

    createList(system);

    if (loadData(system, system->stockFileName, NULL) == TRUE) {
        return TRUE;
    }
    return FALSE;
}

/**
 * Free all memory that has been allocated. If you are struggling to
 * find all your memory leaks, compile your program with the -g flag
 * and run it through valgrind.
 **/
void systemFree(VmSystem *system) {
    freeNode(system);
    freeList(system);
}

/**
 * Loads the stock and coin data into the system. You will also need to assign
 * the char pointers to the stock and coin file names in the system here so
 * that the same files will be used for saving. A key part of this function is
 * validation. A substantial number of marks are allocated to this function.
 **/
Boolean loadData(
        VmSystem *system, const char *stockFileName, const char *coinsFileName) {
    if (loadStock(system, stockFileName) == TRUE) {
        return TRUE;
    }
    return FALSE;
}

/**
 * Loads the stock file data into the system.
 **/
Boolean loadStock(VmSystem *system, const char *fileName) {
    Stock *item;
    FILE *fp;
    char itemBuffer[BUFFSIZE];
    char *idTok, *nameTok, *descTok, *dollarTok, *centTok, *onHandTok;
    char *endOfDollarTok, *endOfCentTok, *endOfOnhand;
    unsigned dollars, cents, onHand;

    fp = fopen(fileName, "r");
    if (fp == NULL) {
        fprintf(stderr, "Unable to open file %s for reading\n", fileName);
    }

    while (TRUE) {

        /* read item from file */
        fgets(itemBuffer, sizeof(itemBuffer), fp);

        if (feof(fp)) {
            break;
        }

        if (itemBuffer[strlen(itemBuffer) - 1] != '\n') {
            readRestOfLine();
        }
        itemBuffer[strlen(itemBuffer) - 1] = '\0';

        if ((item = malloc(sizeof(Stock))) == NULL) {
            fprintf(stderr, "Unable to allocate memory for item\n");
            return FALSE;
        }

        /* tokenize item data */
        idTok = strtok(itemBuffer, STOCK_DELIM);
        nameTok = strtok(NULL, STOCK_DELIM);
        descTok = strtok(NULL, STOCK_DELIM);

        dollarTok = strtok(NULL, PRICE_DELIM);
        centTok = strtok(NULL, STOCK_DELIM);

        onHandTok = strtok(NULL, STOCK_DELIM);

        /* set data for stock item */
        strcpy(item->id, idTok);
        strcpy(item->name, nameTok);
        strcpy(item->desc, descTok);

        dollars = strtol(dollarTok, &endOfDollarTok, BASE);
        item->price.dollars = dollars;

        cents = strtol(centTok, &endOfCentTok, BASE);
        item->price.cents = cents;

        onHand = strtol(onHandTok, &endOfOnhand, 10);
        item->onHand = onHand;

        addNode(system, item);
    }
    fclose(fp);
    return TRUE;
}

/**
 * Loads the coin file data into the system.
 **/
Boolean loadCoins(VmSystem *system, const char *fileName) {

    FILE *fp;
    Coin* coin;
    char coinBuffer[BUFFSIZE];
    char *denomTok, *countTok;
    char *endOfDenom, *endOfCount;
    unsigned denom, count;

    fp = fopen(fileName, "r");
    if (fp == NULL) {
        fprintf(stderr, "Unable to open file %s for reading\n", fileName);
    }

    while (TRUE) {

        /* read item from file */
        fgets(coinBuffer, sizeof(coinBuffer), fp);

        if (feof(fp)) {
            break;
        }

        if (coinBuffer[strlen(coinBuffer) - 1] != '\n') {
            readRestOfLine();
        }
        coinBuffer[strlen(coinBuffer) - 1] = '\0';

        if ((coin = malloc(sizeof(Coin))) == NULL) {
            fprintf(stderr, "Unable to allocate memory for coin\n");
            return FALSE;
        }

        denomTok = strtok(coinBuffer, COIN_DELIM);
        countTok = strtok(NULL, COIN_DELIM);

        denom =  strtol(denomTok, &endOfDenom, BASE);
        count =  strtol(countTok, &endOfCount, BASE);

        if(denom == 5){
            coin->denom = FIVE_CENTS;
        }
        else if(denom == 10){
            coin->denom = TEN_CENTS;
        }
        else if(denom == 20){
            coin->denom = TWENTY_CENTS;
        }
        else if(denom == 50){
            coin->denom = FIFTY_CENTS;
        }
        else if(denom == 100){
            coin->denom = ONE_DOLLAR;
        }
        else if(denom == 200){
            coin->denom = TWO_DOLLARS;
        }
        else if(denom == 500){
            coin->denom = FIVE_DOLLARS;
        }
        else if(denom == 1000){
            coin->denom = TEN_DOLLARS;
        }

        coin->count = count;

        free(coin);
    }
    fclose(fp);

    return TRUE;
}

/**
 * Saves all the stock back to the stock file.
 **/
Boolean saveStock(VmSystem *system) {
    FILE *fp;
    Node *current;

    current = system->itemList->head;

    fp = fopen(system->stockFileName, "w");
    if (fp == NULL) {
        fprintf(stderr, "Unable to open file %s for writing\n", system->stockFileName);
        return FALSE;
    }

    while (current != NULL) {
        fprintf(fp, "%s|%s|%s|%u.%u|%u\n", current->data->id, current->data->name, current->data->desc,
                current->data->price.dollars, current->data->price.cents, current->data->onHand);

        current = current->next;
    }

    fclose(fp);

    return TRUE;
}

/**
 * Saves all the coins back to the coins file.
 **/
Boolean saveCoins(VmSystem *system) {
    return FALSE;
}

int getMaxColumnLen(VmSystem *system) {

    Node *current;
    int max = 0;

    current = system->itemList->head;
    while (current != NULL) {
        if (strlen(current->data->name) > max) {
            max = strlen(current->data->name);
        }
        current = current->next;
    }
    return max;
}


/**
 * This option allows the user to display the items in the system.
 * This is the data loaded into the linked list in the requirement 2.
 **/
void displayItems(VmSystem *system) {
    Node *current;
    int max;

    max = getMaxColumnLen(system);

    current = system->itemList->head;

    printf("Items Menu\n\n%-5s|%-*s|%s|%s\n---------------------------------------------\n",
           "ID", max, "Name", "Available", "Price");

    while (current != NULL) {
        printf("%s|%-*s|%-9u|$%u.%.2u\n", current->data->id, max, current->data->name,
               current->data->onHand, current->data->price.dollars, current->data->price.cents);

        current = current->next;
    }
}

/** checks if input is numeric eg. price inputs**/
enum boolean isNumeric(char *input, char *endOfInput) {
    if (input == endOfInput || *endOfInput != '\0') {
        return FALSE;
    } else {
        return TRUE;
    }
}

/**gets command input by user **/
char *getUserInput(char command[], int lengthCommand) {

    fgets(command, lengthCommand, stdin);
    if (command[strlen(command) - 1] != '\n') {
        readRestOfLine();
    }
    command[strlen(command) - 1] = '\0';

    return command;
}

/**
 * This option allows the user to purchase an item.
 * This function implements requirement 5 of the assignment specification.
 **/
void purchaseItem(VmSystem *system) {
    char *itemID, *amountInput;
    char command[BUFFSIZE];
    Node *current;
    Boolean validID = FALSE;
    char *endOfAmount;
    float amount = 0, owedAmount = 0, payedAmount = 0, itemPrice = 0;

    printf("Purchase Item\n--------------\nPlease enter the id of the item you wish to purchase: ");

    /** get item ID entered by user*/
    itemID = getUserInput(command, sizeof(command));

    if (strlen(itemID) == 0) {
        printf("Cancelling 'purchase item'\n");
        return;
    }

    current = system->itemList->head;
    while (current != NULL) {
        if (strcmp(itemID, current->data->id) == 0) {
            if (current->data->onHand == 0) {
                printf("Error- there is no %s on hand. Please choose another item", current->data->name);
                return;
            }
            /** display info for selected item id*/
            printf("You have selected “%s - %s”. This will cost you $%u.%.2u.\n"
                           "Please hand over the money – type in the value of each note/coin in cents.\n"
                           "Press enter on a new and empty line to cancel this purchase:\nYou still need to give us $%u.%.2u: ",
                   current->data->name, current->data->desc, current->data->price.dollars, current->data->price.cents,
                   current->data->price.dollars, current->data->price.cents);
            validID = TRUE;
            itemPrice = (current->data->price.dollars * CONVERT_PRICE) + current->data->price.cents;
            owedAmount = (current->data->price.dollars * CONVERT_PRICE) + current->data->price.cents;
            while (payedAmount < itemPrice) {
                /** get amount in cents entered by user*/
                amountInput = getUserInput(command, sizeof(command));

                amount = strtol(amountInput, &endOfAmount, BASE);
                if (strlen(amountInput) == 0) {
                    printf("Change of mind- here is your change: $%.2f\n"
                                   "Please come again soon\n", payedAmount / CONVERT_PRICE);
                    return;
                }
                if (amount == FIVE_CENTS || amount == TEN_CENTS || amount == TWENTY_CENTS || amount == FIFTY_CENTS ||
                    amount == ONE_DOLLAR || amount == TWO_DOLLARS || amount == FIVE_DOLLARS ||
                    amount == TEN_DOLLARS) { /** ie. valid amount entered*/
                    if (amount >= owedAmount) {
                        printf("Thank you. Here is your %s, and your change of $%.2f.\n"
                                       "Please come back soon.\n", current->data->name,
                               (amount - owedAmount) / CONVERT_PRICE);
                        current->data->onHand--;
                        return;
                    } else {
                        payedAmount += amount;
                        owedAmount -= amount;
                        printf("You still need to give us $%.2f:", owedAmount / CONVERT_PRICE);
                    }
                } else {
                    if (isNumeric(amountInput, endOfAmount) == TRUE) {
                        printf("Error: $%.2f is not a valid denomination of money. Please try again.\n",
                               amount / CONVERT_PRICE);
                    } else {
                        printf("Invalid amount- not a number\n");
                    }
                    printf("You still need to give us $%.2f:", owedAmount / CONVERT_PRICE);
                }
            }
        }
        current = current->next;
    }
    if (validID == FALSE) {
        printf("Error- invalid id entered. Please try again\n\n");
        purchaseItem(system);
    }
}

/**
 * You must save all data to the data files that were provided on the command
 * line when the program loaded up, display goodbye and free the system.
 * This function implements requirement 6 of the assignment specification.
 **/
void saveAndExit(VmSystem *system) {
    saveStock(system);
    printf("Goodbye!\n");
    systemFree(system);
    exit(0);
}

/** get the item id number of the new item to be added to the list */
int getNewIdNum(VmSystem *system) {

    Node *current;
    char lastCharId;
    int idNum;
    int idNums[BUFFSIZE];
    int i = 0, index = 0, maxId = 0;

    char lastTwoCharId[CHAR_ID_LEN];
    char *endOfTwoCharId;

    current = system->itemList->head;

    /** populate array of ints with the item id number of each node*/
    while (current != NULL) {

        if ((current->data->id[3] - '0') >= 1) {
            strcpy(lastTwoCharId, current->data->id + 3);
            idNum = strtol(lastTwoCharId, &endOfTwoCharId, BASE);
        } else {
            lastCharId = current->data->id[strlen(current->data->id) - 1];
            idNum = lastCharId - '0'; /* converts char to int */
        }
        idNums[i] = idNum;
        current = current->next;
        i++;
    }

    /**get the max item id number in the array */
    for (index = 0; index < system->itemList->size; index++) {
        if (idNums[index] > maxId) {
            maxId = idNums[index];
        }
    }

    return (maxId + 1);
}


/** sets a valid item price for a new item to be added*/
void setValidPriceInput(char priceInput[], Stock *item) {

    char *dollarTok, *centTok;
    char *endOfDollarTok, *endOfCentTok;
    unsigned dollars, cents;

    printf("Enter the price for this item: ");
    fgets(priceInput, BUFFSIZE, stdin);
    if (priceInput[strlen(priceInput) - 1] != '\n') {
        readRestOfLine();
    }
    priceInput[strlen(priceInput) - 1] = '\0';

    if (strlen(priceInput) == 0) {
        printf("Cancelling 'add item'\n");
        return;
    }

    if ((priceInput[1] == '.' || priceInput[2] == '.') &&
        (strlen(priceInput) == 4 || strlen(priceInput) == 5)) {
        dollarTok = strtok(priceInput, PRICE_DELIM);
        centTok = strtok(NULL, "");

        dollars = strtol(dollarTok, &endOfDollarTok, BASE);

        cents = strtol(centTok, &endOfCentTok, BASE);

        if (isNumeric(dollarTok, endOfDollarTok) && isNumeric(centTok, endOfCentTok) &&
            dollars >= MIN_DOLLARS && dollars <= MAX_DOLLARS && ((cents % MULTIPLE_5) == 0 || cents == 0)
            && cents >= MIN_CENTS && cents <= MAX_CENTS) {
            item->price.dollars = dollars;
            item->price.cents = cents;
            return;
        } else {
            printf("Invalid price\n");
            setValidPriceInput(priceInput, item);
        }
    } else {
        printf("Invalid price\n");
        setValidPriceInput(priceInput, item);
    }

}


/**
 * This option adds an item to the system. This function implements
 * requirement 7 of of assignment specification.
 **/
void addItem(VmSystem *system) {
    Stock *item;
    char *nameInput, *descInput;
    char command[BUFFSIZE], priceInput[BUFFSIZE];

    char newItemId[NEW_ID_LEN];
    char newIdNumber[NEW_ID_NUM_LEN];

    if ((item = malloc(sizeof(Stock))) == NULL) {
        fprintf(stderr, "Unable to allocate memory for item\n");
        return;
    }

    /** create new item id using new item id number*/
    if (getNewIdNum(system) > LARGE_ID) {
        sprintf(newIdNumber, "%d", getNewIdNum(system));
        strcpy(newItemId, "I00");
        strncat(newItemId, newIdNumber, ID_NUM_LEN_2);
        strcpy(item->id, newItemId);
    } else {
        sprintf(newIdNumber, "%d", getNewIdNum(system));
        strcpy(newItemId, "I000");
        strncat(newItemId, newIdNumber, ID_NUM_LEN_1);
        strcpy(item->id, newItemId);
    }

    printf("This new meal item will have the Item id of %s.\n", item->id);

    do {
        printf("Enter the item name:");
        nameInput = getUserInput(command, sizeof(command));
    } while (strlen(nameInput) > NAME_LEN);

    if (strlen(nameInput) == 0) {
        printf("Cancelling 'add item'\n");
        return;
    }

    strcpy(item->name, nameInput);

    do {
        printf("Enter the item description: ");
        descInput = getUserInput(command, sizeof(command));
    } while (strlen(descInput) > DESC_LEN);

    if (strlen(descInput) == 0) {
        printf("Cancelling 'add item'\n");
        return;
    }

    strcpy(item->desc, descInput);

    /* sets item price*/
    setValidPriceInput(priceInput, item);

    /* cancel 'add item' if price not set*/
    if (item->price.dollars == 0 && item->price.cents == 0) {
        return;
    }

    item->onHand = DEFAULT_STOCK_LEVEL;

    printf("This item “%s – %s.” has now been added to the menu.\n", item->name, item->desc);

    addNode(system, item);
}

/**
 * Remove an item from the system, including free'ing its memory.
 * This function implements requirement 8 of the assignment specification.
 **/
void removeItem(VmSystem *system) {
    Node *current, *previous, *currNode;
    char *removeId;
    char command[BUFFSIZE];
    Stock *data;
    Boolean idExists = FALSE;

    /**get item id to delete*/
    printf("Enter the item id of the item to remove from the menu: ");
    removeId = getUserInput(command, sizeof(command));

    if (strlen(removeId) == 0) {
        printf("Cancelling 'remove item'\n");
        return;
    }

    if ((data = malloc(sizeof(Stock))) == NULL) {
        fprintf(stderr, "Unable to allocate memory for stock data\n");
        return;
    }

    /** check if given item id exists in list*/
    currNode = system->itemList->head;
    while (currNode != NULL) {
        if (strcmp(currNode->data->id, removeId) == 0) {
            printf("Id exists in list\n");
            strcpy(data->id, removeId);
            strcpy(data->name, currNode->data->name);
            strcpy(data->desc, currNode->data->desc);
            idExists = TRUE;
        }
        currNode = currNode->next;
    }

    if (idExists == TRUE) {
        current = system->itemList->head;
        if (current == NULL) { /* attempting to remove item from empty list */
            fprintf(stderr, "Can't delete item from empty list\n");
            exit(EXIT_FAILURE);
        }

        if (strcmp(data->id, current->data->id) == 0) {  /* remove first item in list*/
            system->itemList->head = system->itemList->head->next;
            free(current->data);
            free(current);
        } else {
            previous = current;    /* remove item in middle of list */
            while (current != NULL) {
                if (strcmp(data->id, current->data->id) == 0)
                    break;
                else {
                    previous = current;
                    current = current->next;
                }
            }
            if (current == NULL) {
                fprintf(stderr, "Item not found in list\n");
                exit(EXIT_FAILURE);
            }
            previous->next = current->next;
            free(current->data);
            free(current);
        }
        system->itemList->size--;

        printf("“%s – %s  %s” has been removed from the system.", data->id, data->name, data->desc);
        free(data);
    } else {
        printf("Id does not exist\n");
        free(data);
        removeItem(system);
    }
}

/**
 * This option will require you to display the coins from lowest to highest
 * value and the counts of coins should be correctly aligned.
 * This function implements part 4 of requirement 18 in the assignment
 * specifications.
 **/
void displayCoins(VmSystem *system) {

    int i;
    printf("Coins Summary\n  ---------\n Denomination | Count \n ");
    for(i = 0; i < NUM_DENOMS; i++){
        printf("%u           |  %u\n", system->cashRegister[i].denom,
               system->cashRegister[i].count);
    }
}

/**
 * This option will require you to iterate over every stock in the
 * list and set its onHand count to the default value specified in
 * the startup code.
 * This function implements requirement 9 of the assignment specification.
 **/
void resetStock(VmSystem *system) {
    Node *current;

    current = system->itemList->head;
    while (current != NULL) {
        current->data->onHand = DEFAULT_STOCK_LEVEL;
        current = current->next;
    }
    printf("All stock has been reset to the default level of %d\n", DEFAULT_STOCK_LEVEL);
}

/**
 * This option will require you to iterate over every coin in the coin
 * list and set its 'count' to the default value specified in the
 * startup code.
 * This requirement implements part 3 of requirement 18 in the
 * assignment specifications.
 **/
void resetCoins(VmSystem *system) {
    int i = 0;
    for(i = 0; i < NUM_DENOMS; i++){
        system->cashRegister[i].count = DEFAULT_COIN_COUNT;
    }

    printf("All coins have been reset to the default level of %d\n",
           DEFAULT_COIN_COUNT);
}

/**
 * This option will require you to display goodbye and free the system.
 * This function implements requirement 10 of the assignment specification.
 **/
void abortProgram(VmSystem *system) {
    printf("Goodbye\n");
    systemFree(system);
    exit(0);
}
