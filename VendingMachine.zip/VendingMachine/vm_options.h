/******************************************************************************
** Student name: 	Christina Terranova
** Student number: 	s3655948
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#ifndef VM_OPTIONS_H
#define VM_OPTIONS_H

#include "vm_stock.h"

#define PRICE_DELIM "."
#define BUFFSIZE 1000
#define BASE 10
#define CONVERT_PRICE 100
#define MIN_DOLLARS 0
#define MAX_DOLLARS 99
#define MIN_CENTS 0
#define MAX_CENTS 95
#define MULTIPLE_5 5

#define CHAR_ID_LEN 3

#define NEW_ID_LEN 6
#define NEW_ID_NUM_LEN 3
#define LARGE_ID 9
#define ID_NUM_LEN_1 1
#define ID_NUM_LEN_2 2

#define FIVE_CENTS 5
#define TEN_CENTS 10
#define TWENTY_CENTS 20
#define FIFTY_CENTS 50
#define ONE_DOLLAR 100
#define TWO_DOLLARS 200
#define FIVE_DOLLARS 500
#define TEN_DOLLARS 1000

Boolean systemInit(VmSystem * system);
void systemFree(VmSystem * system);
Boolean loadData(
    VmSystem * system, const char * stockFileName, const char * coinsFileName);
Boolean loadStock(VmSystem * system, const char * fileName);
Boolean loadCoins(VmSystem * system, const char * fileName);
Boolean saveStock(VmSystem * system);
Boolean saveCoins(VmSystem * system);
void displayItems(VmSystem * system);
void purchaseItem(VmSystem * system);
void saveAndExit(VmSystem * system);
void addItem(VmSystem * system);
void removeItem(VmSystem * system);
void displayCoins(VmSystem * system);
void resetStock(VmSystem * system);
void resetCoins(VmSystem * system);
void abortProgram(VmSystem * system);

#endif
